<template>
  <div class="hello">
    <div class="row">
      <div class="col s12 center">
        <img src="../assets/logo.png" alt="Vue" />
      </div>
      <h1 class="center-align">🎉 Добро пожаловать ! 🥳</h1>
      <h2 class="center-align">На решение этого test-case</h2>
      <h3 class="center-align">
        <a href="https://github.com/">Это решение на GitHub</a>
      </h3>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
};
</script>
