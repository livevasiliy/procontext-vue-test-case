<template>
  <div class="about">
    <div class="row">
      <div class="col s12 center">
        <img
          src="../assets/avatar.jpg"
          alt="Vue"
          class="responsive-img"
          width="500"
          height="500"
        />
      </div>
      <h1 class="center-align">🎉 Добро пожаловать ! 🥳</h1>
      <h2 class="center-align">На решение этого test-case</h2>
      <h4 class="center">Я в соц.сетях:</h4>
      <ul class="collection center">
        <li class="collection-item">
          <a href="https://vk.com/livevasiliy">ВКонтакте</a>
        </li>
        <li class="collection-item">
          <a href="https://instagram.com/livevasiliy">Инста</a>
        </li>
        <li class="collection-item">
          <a
            href="https://spb.hh.ru/resume/d649a939ff05878a860039ed1f73504745434f"
            >Резюме на HH.ru</a
          >
        </li>
      </ul>
    </div>
  </div>
</template>
